package com.example.alphapay;

public class payment {

    String id;
    String amount;
    String account;
    int pin;

    public payment() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getamount() {
        return amount;
    }

    public void setName(String amount) {
        this.amount= amount;
    }

    public String getaccount() {
        return account;
    }

    public void setAddress(String account) {
        this.account = account;
    }

    public int getpin() {
        return pin;
    }

    public void setpin(int pin) {
        this.pin = pin;
    }



    public payment(String id, String amount, String  account, int pin) {
        this.id = id;
        this.amount = amount;
        this.account = account;
        this.pin= pin;
    }
}

