package com.example.alphapay;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    EditText id,amount,account,pin;
    Button save, show, update, delete;

    DatabaseReference dbref;
    payment std;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        id = findViewById(R.id.txt_id);
        amount = findViewById(R.id.txt_name);
        account = findViewById(R.id.txt_address);
        pin = findViewById(R.id.txt_contact);

        save = findViewById(R.id.btn_save);
        show = findViewById(R.id.btn_show);
        update = findViewById(R.id.btn_update);
        delete = findViewById(R.id.btn_delete);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbref = FirebaseDatabase.getInstance().getReference().child("payment");

                String sid = id.getText().toString();
                String samount= amount.getText().toString();
                String saccount = account.getText().toString();
                int spin = Integer.parseInt(pin.getText().toString());

                std = new payment(sid,samount,saccount,spin);

                dbref.child(sid).setValue(std);
                clearControlls();

                Toast.makeText(getApplicationContext(),"Data Saved Successfully",Toast.LENGTH_SHORT).show();
            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sid = id.getText().toString();
                DatabaseReference readref = FirebaseDatabase.getInstance().getReference().child("payment").child(sid);

                readref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChildren()) {
                            id.setText(dataSnapshot.child("id").getValue().toString());
                            amount.setText(dataSnapshot.child("name").getValue().toString());
                            account.setText(dataSnapshot.child("address").getValue().toString());
                            pin.setText(dataSnapshot.child("contactNo").getValue().toString());
                        } else {
                            Toast.makeText(getApplicationContext(), "No Source to display", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference updRef = FirebaseDatabase.getInstance().getReference().child("payment");
                updRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String sid = id.getText().toString();
                        String samount = amount.getText().toString();
                        String saccount = account.getText().toString();
                        int spin= Integer.parseInt(pin.getText().toString());


                        if(dataSnapshot.hasChild(sid))
                        {
                            std = new payment(sid,samount,saccount,spin);
                            dbref = FirebaseDatabase.getInstance().getReference().child("payment").child(sid);
                            dbref.setValue(std);
                            clearControlls();

                            Toast.makeText(getApplicationContext(),"Update Successfully",Toast.LENGTH_SHORT).show();
                        }else
                        {
                            Toast.makeText(getApplicationContext(),"No Source to Update",Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final DatabaseReference delRef = FirebaseDatabase.getInstance().getReference().child("payment");

                delRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String sid = id.getText().toString();
                        if (dataSnapshot.hasChild(sid)) {
                            dbref = FirebaseDatabase.getInstance().getReference().child("payment").child(sid);
                            dbref.removeValue();
                            clearControlls();

                            Toast.makeText(getApplicationContext(), "Data Deleted Successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "No Data Delete", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

        });
    }










    public void clearControlls()
    {
        id.setText("");
        amount.setText("");
        account.setText("");
        pin.setText("");
    }
}


